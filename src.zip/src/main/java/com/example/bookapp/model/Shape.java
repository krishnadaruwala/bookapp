package com.example.bookapp.model;

public abstract class Shape {
    public abstract double getArea();
}
