package com.example.bookapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ExceptionController {

    @GetMapping("/exception")
    public String showForm() {
        return "exceptionform";
    }

    @PostMapping("/exception")
    public String handleDivision(
            @RequestParam double num1,
            @RequestParam double num2,
            Model model) {
        try {
            double result = num1 / num2;
            model.addAttribute("result", result);
        } catch (ArithmeticException | IllegalArgumentException e) {
            model.addAttribute("result", "Error: " + e.getMessage());
        }
        return "exceptionresult";
    }
}
