package com.example.bookapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.bookapp.model.ArrayProcessor;

@Controller
public class ArrayController {

    @GetMapping("/array")
    public String showForm(Model model) {
        model.addAttribute("arrayProcessor", new ArrayProcessor());
        return "array-form";
    }

    @PostMapping("/array")
    public String processArray(@ModelAttribute ArrayProcessor arrayProcessor, Model model) {
        model.addAttribute("sorted", arrayProcessor.getSortedArray());
        model.addAttribute("reversed", arrayProcessor.getReversedArray());
        model.addAttribute("original", arrayProcessor.getNumbers());
        return "array-result";
    }
}
