package com.example.bookapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.bookapp.model.Shape;
import com.example.bookapp.model.ShapeCircle;
import com.example.bookapp.model.ShapeRectangle;

@Controller
public class ShapeController {

    @GetMapping("/shape")
    public String showForm() {
        return "shape-form";
    }

    @PostMapping("/shape")
    public String calculateArea(
        @RequestParam String shapeType,
        @RequestParam(required = false) Double radius,
        @RequestParam(required = false) Double length,
        @RequestParam(required = false) Double width,
        Model model) {

        Shape shape;
        double area;

        if ("circle".equals(shapeType)) {
            shape = new ShapeCircle(radius);
        } else {
            shape = new ShapeRectangle(length, width);
        }

        area = shape.getArea();
        model.addAttribute("area", area);
        model.addAttribute("shapeType", shapeType);

        return "shape-result";
    }
}
